﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace operatorok
{
    internal class feladat
    {
        int operandus1, operandus2;
        string operátor;
        public feladat(int op1, int op2, string operátor)
        {
            operandus1 = op1;
            operandus2 = op2;
            this.operátor = operátor;
        }


        static List<feladat> feladatok;

        public int Operandus1 { get => operandus1;  }
        public int Operandus2 { get => operandus2;  }
        public string Operátor { get => operátor;  }

        public void FajlBeolvasasa(string FajlNev)
        {foreach (var sor in File.ReadAllLines(FajlNev))

            {int a = int.Parse(sor.Split()[0]);
             int b = int.Parse(sor.Split()[2]);
             string o = sor.Split()[1];
             feladatok.Add(new feladat(a, b, o));}
        }
    }
}
