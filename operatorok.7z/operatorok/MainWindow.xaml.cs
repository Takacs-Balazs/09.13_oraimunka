﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace operatorok
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<feladat> feladatok = new List<feladat>();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var fajl = new OpenFileDialog();
            if (fajl.ShowDialog()== true)
            {
                StreamReader sr = new StreamReader(fajl.FileName);
                while (!sr.EndOfStream)
                {
                    string sor = sr.ReadLine();
                    string[] mezok = sor.Split(" ");
                    feladat kifejezes = new feladat(Convert.ToInt32(mezok[0]), Convert.ToInt32(mezok[2]), mezok[1]);
                    feladatok.Add(kifejezes);
                }
                sr.Close();

            }
            cimke.Content = $"2. feladat: (kifejezeseknek szama): {feladatok.Count}";
            OsztasEredmeny.Content = $"3.feladat: (Osztasok szama): {feladatok.Count(x => x.Operátor == "mod")}";
            vaneeredmeny.Content = $"4. feladat: {(feladatok.FirstOrDefault(a => a.Operandus1 % 10 == 0 && a.Operandus2 % 10 == 0) != null ? "Van ilyen kifejezés" : "Nincs ilyen kifejezés")}";
            lb5.Items.Add("5. feladat: Statisztika");
            lb5.Items.Add($"\tmod -> {feladatok.Count(a => a.Operátor == "mod")} db");
            lb5.Items.Add($"\t  / -> {feladatok.Count(a => a.Operátor == "/")} db");
            lb5.Items.Add($"\tdiv -> {feladatok.Count(a => a.Operátor == "div")} db");
            lb5.Items.Add($"\t  - -> {feladatok.Count(a => a.Operátor == "-")} db");
            lb5.Items.Add($"\t  * -> {feladatok.Count(a => a.Operátor == "*")} db");
            lb5.Items.Add($"\t  + -> {feladatok.Count(a => a.Operátor == "+")} db");


        }
    }
}
